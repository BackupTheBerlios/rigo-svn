/***************************************************************************
 *   Copyright (C) 2005 by Siafu86   *
 *   siafu86@rigo.berlios.de   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "toolbox.h"



namespace std {

	Toolbox::Toolbox()
	{/**Check the recent documents list.
			Prompt User to start a new Project if 
			none found */
	}
	
	
	Toolbox::~Toolbox()
	{
	}
	/*
	void Toolbox::save(Notebook myBook, string filename){
		
	
	}
	
	file Toolbox::open(string filename){
		
	}
	
	void Toolbox::writeOutline(string filetype, int style){
		
	}
	
	void Toolbox::Recover(){
		
	}
	
	void Toolbox::import(Notebook aNotebook){
		
	}
	
	void Toolbox::import(Document aPaper){
		
	}
	
	void Toolbox::writeCompilation(string filetype, int style){
		
	}*/
}
